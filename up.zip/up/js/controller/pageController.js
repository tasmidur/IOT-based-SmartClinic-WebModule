//page config
if(!localStorage.hasOwnProperty("islogin")){
    console.log(localStorage.hasOwnProperty("islogin"));
    window.location.href = "login.html";
}



